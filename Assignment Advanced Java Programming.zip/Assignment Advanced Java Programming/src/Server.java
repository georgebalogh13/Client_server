import java.io.*;
import java.net.*;

public class Server {

    public static void trimiteDateLaClient (DataOutputStream dos, String sir) throws IOException{

        dos.writeUTF(sir);
        dos.flush();
        System.out.println("Am trimis către client: " + sir);

    }

    public static String primesteDateDeLaClient (DataInputStream dis) throws IOException{

        String sir = dis.readUTF();
        System.out.println("Am primit de la client: " + sir);
        return sir;

    }

    public static void main (String[] args){

        DataInputStream dis = null;
        DataOutputStream dos = null;
        Socket s = null;
        ServerSocket server = null;
        try{
            server = new ServerSocket(2001);
            s = server.accept();
            System.out.println("Conectarea clientului a fost efectuată");
            dis = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            dos = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));

        } catch (IOException e){
            System.out.println("Eroare la conectare: " + e);

        }

        String sirDouble = "";
        double dUnu = 0.0, dDoi = 0.0;
        double sumaDouble = 0.0;
        try {
            sirDouble = primesteDateDeLaClient(dis);
            Double d1Temp = Double.valueOf(sirDouble);
            dUnu = d1Temp.doubleValue();
            sirDouble = primesteDateDeLaClient(dis);
            d1Temp = Double.valueOf(sirDouble);
            dDoi = d1Temp.doubleValue();
            sumaDouble = dUnu + dDoi;
            trimiteDateLaClient(dos, Double.toString(sumaDouble));

        } catch (IOException e){
            System.out.println("Eroare la trimitere și primire date: " + e);

        }

        System.out.println(dUnu + " + " + dDoi + " = " + sumaDouble);

    }
}

