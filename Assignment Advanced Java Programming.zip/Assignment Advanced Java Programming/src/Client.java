import java.io.*;
import java.net.*;

public class Client {

    public static void trimiteDateLaClient(DataOutputStream dos, String sir) throws IOException{

        dos.writeUTF(sir);
        dos.flush();
        System.out.println("Am trimis către server: " + sir);

    }

    public static String primesteDateDeLaServer(DataInputStream dis) throws IOException{

        String sir = dis.readUTF();
        System.out.println("Am primit de la server: " + sir);
        return sir;

    }

    public static void main(String[] args){

        DataInputStream dis = null;
        DataOutputStream dos = null;
        Socket s = null;
        try{
            s = new Socket("127.0.0.1", 2001);
            System.out.println("Am fost conectați la serverul sumaDouble");
            dis = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            dos = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
        } catch (IOException e){
            System.out.println("Eroare la conectare: " + e);

        }

        double dUnu = 0.0, dDoi = 0.0;
        BufferedReader in;
        String line;
        try{
            in = new BufferedReader(new InputStreamReader(System.in));
            System.out.flush();
            System.out.println("Introduceți primul număr double:");
            line = in.readLine();
            Double d1Temp = Double.valueOf(line);
            dUnu = d1Temp.doubleValue();
            System.out.flush();
            System.out.println("Introduceți cel de-al doilea număr double:");
            line = in.readLine();
            d1Temp = Double.valueOf(line);
            dDoi = d1Temp.doubleValue();
            in.close();

        } catch (IOException e){
            System.out.println("Citirea de la tastatură s-a efectuat greșit " + e.toString());

        }

        String sirDouble = "";
        try
        {
            trimiteDateLaClient(dos, Double.toString(dUnu));
            trimiteDateLaClient(dos, Double.toString(dDoi));
            sirDouble = primesteDateDeLaServer(dis);

        }
        catch (IOException e)
        {
            System.out.println("Eroare la trimitere și primire date: " + e);

        }

        System.out.println(dUnu + " + " + dDoi + " = " + sirDouble);

    }
}
